﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using POCInstrumentoCuerda.model;

namespace POCInstrumentoCuerda
{
    public partial class GUIListarInstrumentoCuerda : Form, ICambiable
    {
        private readonly TextBox filtroNombre = new TextBox();
        private readonly TextBox filtroPrecioMaximo = new TextBox();
        private List<Instrumento> instrumentos = new List<Instrumento>();
        private bool listaCargada;

        public GUIListarInstrumentoCuerda()
        {
            InitializeComponent();
            Controls.Add(new Label { Text = "Nombre:", Location = new Point(77, 60), AutoSize = true });
            filtroNombre.SetBounds(125, 57, 120, 20);
            Controls.Add(filtroNombre);
            Controls.Add(new Label { Text = "Precio máximo:", Location = new Point(270, 60), AutoSize = true });
            filtroPrecioMaximo.SetBounds(365, 57, 100, 20);
            Controls.Add(filtroPrecioMaximo);
            btnListar.Click += async delegate { await ListarAsync(); };
            this.StartPosition = FormStartPosition.CenterScreen;
            ServicioObserver.Agregar(this);
            FormClosed += (s, e) => ServicioObserver.Eliminar(this);
        }

        private async Task ListarAsync()
        {
            try
            {
                double? filtroPrecio = Validaciones.PrecioMaximoOpcional(filtroPrecioMaximo.Text);

                instrumentos = await GraphQLService.ListarAsync(
                    string.IsNullOrWhiteSpace(filtroNombre.Text) ? null : filtroNombre.Text.Trim(),
                    filtroPrecio);
                tableInstrumentosCuerda.Rows.Clear();
                foreach (var instrumento in instrumentos)
                {
                    tableInstrumentosCuerda.Rows.Add(instrumento.id, instrumento.nombre, instrumento.precio,
                        instrumento.fechaVenta, instrumento.numeroTrastes, instrumento.numeroCuerdas,
                        string.Join("; ", (instrumento.accesorio ?? new List<Accesorio>())
                            .Select(a => $"{a.nombre} (${a.precio:0.##}, {a.marca})")));
                }
                listaCargada = true;
            }
            catch (Exception exception) { MessageBox.Show(Validaciones.MensajeDeError(exception), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }


        public void Cambio()
        {
            if (!listaCargada || IsDisposed || !IsHandleCreated) return;
            if (InvokeRequired)
            {
                try { BeginInvoke(new Action(async () => await ListarAsync())); } catch (InvalidOperationException) { }
            }
            else
            {
                _ = ListarAsync();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
