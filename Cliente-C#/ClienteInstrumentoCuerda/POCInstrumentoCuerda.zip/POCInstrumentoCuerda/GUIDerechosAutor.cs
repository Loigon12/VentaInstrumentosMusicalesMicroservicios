﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POCInstrumentoCuerda
{
    public partial class GUIDerechosAutor : Form
    {
        public GUIDerechosAutor()
        {
            InitializeComponent();
            Text = "Acerca de...";
            Controls.Add(new Label
            {
                Text = "POC Instrumento de Cuerda - Versión 1.0.0",
                AutoSize = true,
                ForeColor = Color.White,
                Location = new Point(288, 330)
            });
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
