package com.example.POCEmpleado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocEmpleadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
